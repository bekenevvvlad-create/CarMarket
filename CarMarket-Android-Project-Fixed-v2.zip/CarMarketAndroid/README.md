# CarMarket 2.0

CarMarket is a virtual Android car-market simulator. All money, banking and deals are fictional and local to the game.

## Included in this version
- Dark smartphone-style interface
- Car photo-style image assets bundled in the APK
- Marketplace search and category filters
- City-specific listings for Amsterdam, Berlin, Paris, Munich and Rotterdam
- Car detail screens with condition, inspection and accident history
- Negotiation / counter-offer system
- Buy, sell and player listings
- Garage with service and tuning
- Virtual bank with savings and fictional loans
- Travel between cities
- Dealership leveling, employees and reputation
- Missions, XP, achievements and transaction history
- Local save data with SharedPreferences

## Build
The repository workflow can extract `CarMarket-Android-Project-Updated.zip` and build `project/CarMarketAndroid` with Java 17 and Gradle 8.11.1.
