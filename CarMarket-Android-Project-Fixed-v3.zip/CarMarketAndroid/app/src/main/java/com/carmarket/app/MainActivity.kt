package com.carmarket.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.text.TextWatcher
import android.text.Editable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class MainActivity : Activity() {
    private val cities = listOf("Amsterdam", "Berlin", "Paris", "Munich", "Rotterdam")
    private val dark = Color.rgb(8, 11, 17)
    private val panel = Color.rgb(20, 27, 38)
    private val panel2 = Color.rgb(27, 36, 49)
    private val accent = Color.rgb(74, 163, 255)
    private val accent2 = Color.rgb(118, 86, 255)
    private val green = Color.rgb(87, 222, 137)
    private val yellow = Color.rgb(246, 196, 73)
    private val red = Color.rgb(245, 98, 108)
    private val muted = Color.rgb(160, 172, 190)

    private enum class Screen { HOME, MARKET, GARAGE, BANK, PROFILE }
    private var screen = Screen.HOME
    private var currentCity = "Amsterdam"
    private var cash = 25000
    private var savings = 0
    private var loan = 0
    private var dealershipLevel = 1
    private var dealershipXp = 0
    private var reputation = 15
    private var deals = 0
    private var selectedFilter = "Все"
    private var maxPrice = 50000
    private var searchQuery = ""

    private val owned = mutableListOf<Car>()
    private val listings = mutableListOf<Car>()
    private val history = mutableListOf<String>()
    private val missions = mutableListOf<Mission>()
    private var hasSavedMarket = false
    private val garageCapacity: Int get() = 7 + dealershipLevel

    private data class Car(
        val id: Int,
        val name: String,
        val details: String,
        var price: Int,
        var condition: Int,
        val city: String,
        val seller: String,
        val category: String,
        val image: Int,
        val accident: Boolean = false,
        var tuned: Int = 0,
        var inspected: Boolean = false
    )

    private data class Mission(var title: String, var progress: Int, val target: Int, val reward: Int, var claimed: Boolean = false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = dark
        window.navigationBarColor = dark
        loadGame()
        if (!hasSavedMarket) {
            val playerListings = listings.toList()
            listings.clear()
            seedListings()
            listings.addAll(0, playerListings)
        }
        if (missions.isEmpty()) seedMissions()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 16) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun label(value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = true
        }

    private fun iconText(icon: String, title: String, subtitle: String? = null, onClick: (() -> Unit)? = null): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = bg(panel, 14)
            setPadding(dp(13), dp(11), dp(13), dp(11))
            if (onClick != null) setOnClickListener { onClick() }
        }
        val ico = label(icon, 25f, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        row.addView(ico, LinearLayout.LayoutParams(dp(44), dp(44)))
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, 0, 0) }
        texts.addView(label(title, 15f, Color.WHITE, true))
        if (subtitle != null) texts.addView(label(subtitle, 12f, muted).apply { setPadding(0, dp(2), 0, 0) })
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        if (onClick != null) row.addView(label("›", 26f, muted))
        return row
    }

    private fun button(text: String, action: () -> Unit, color: Int = accent): TextView = TextView(this).apply {
        this.text = text
        textSize = 13f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = bg(color, 12)
        setPadding(dp(13), dp(11), dp(13), dp(11))
        setOnClickListener { action() }
    }

    private fun pill(text: String, selected: Boolean, action: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(if (selected) Color.WHITE else muted)
        gravity = Gravity.CENTER
        background = bg(if (selected) accent else panel2, 18)
        setPadding(dp(12), dp(8), dp(12), dp(8))
        setOnClickListener { action() }
    }

    private fun spacer(h: Int = 8) = Space(this).apply { minimumHeight = dp(h) }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(dp(14), dp(10), dp(14), dp(8))
        }
        root.addView(topBar())
        val scroll = ScrollView(this).apply { isFillViewport = true; clipToPadding = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(6), 0, dp(14)) }
        when (screen) {
            Screen.HOME -> homePage(content)
            Screen.MARKET -> marketPage(content)
            Screen.GARAGE -> garagePage(content)
            Screen.BANK -> bankPage(content)
            Screen.PROFILE -> profilePage(content)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(bottomNav())
        setContentView(root)
    }

    private fun topBar(): LinearLayout {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        brand.addView(label("CarMarket", 23f, Color.WHITE, true))
        brand.addView(label("${currentCity} · рынок открыт", 12f, muted))
        bar.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val wallet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            background = bg(panel2, 12)
            setPadding(dp(10), dp(6), dp(10), dp(6))
        }
        wallet.addView(label("€ ${cash.formatMoney()}", 15f, green, true))
        wallet.addView(label("Уровень ${dealershipLevel}", 11f, muted))
        bar.addView(wallet)
        return bar
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) }
        val items = listOf(
            Triple(Screen.HOME, "⌂", "Главная"),
            Triple(Screen.MARKET, "🚘", "Рынок"),
            Triple(Screen.GARAGE, "▣", "Гараж"),
            Triple(Screen.BANK, "▥", "Банк"),
            Triple(Screen.PROFILE, "●", "Профиль")
        )
        items.forEach { item ->
            val active = screen == item.first
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(7), dp(4), dp(6))
                if (active) background = bg(panel2, 12)
                setOnClickListener { screen = item.first; render() }
            }
            v.addView(label(item.second, 19f, if (active) accent else muted, true).apply { gravity = Gravity.CENTER })
            v.addView(label(item.third, 10f, if (active) Color.WHITE else muted).apply { gravity = Gravity.CENTER })
            nav.addView(v, LinearLayout.LayoutParams(0, -2, 1f))
        }
        return nav
    }

    private fun section(parent: LinearLayout, title: String, subtitle: String? = null) {
        parent.addView(label(title, 20f, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(4)) })
        if (subtitle != null) parent.addView(label(subtitle, 12f, muted).apply { setPadding(0, 0, 0, dp(9)) })
    }

    private fun statCard(parent: LinearLayout, title: String, value: String, icon: String, color: Int) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(panel, 14); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        card.addView(label(icon, 20f, color, true))
        card.addView(label(title, 11f, muted).apply { setPadding(0, dp(4), 0, 0) })
        card.addView(label(value, 15f, Color.WHITE, true).apply { setPadding(0, dp(2), 0, 0) })
        parent.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
    }

    private fun homePage(parent: LinearLayout) {
        val hero = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(panel, 18); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        hero.addView(label("🚗  Твой автомобильный мир", 21f, Color.WHITE, true))
        hero.addView(label("Покупай дешевле, продавай дороже, торгуйся и развивай свой автосалон.", 12f, muted).apply { setPadding(0, dp(5), 0, dp(12)) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        statCard(row, "Денег", "€ ${cash.formatMoney()}", "€", green)
        statCard(row, "В гараже", owned.size.toString(), "🚘", accent)
        statCard(row, "Сделок", deals.toString(), "↕", yellow)
        hero.addView(row)
        parent.addView(hero)

        section(parent, "Быстрые действия")
        val quick = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        quick.addView(iconText("🔎", "Найти автомобиль", "Фильтры, цены, города", { screen = Screen.MARKET; render() }), lpBottom())
        quick.addView(iconText("🏦", "Игровой банк", "Накопления, кредиты, история", { screen = Screen.BANK; render() }), lpBottom())
        quick.addView(iconText("🔧", "Сервис и тюнинг", "Ремонт, осмотр, улучшения", { openServiceHub() }), lpBottom())
        quick.addView(iconText("🗺️", "Города и поездки", "5 городов, разные цены", { openCities() }), lpBottom())
        quick.addView(iconText("🏢", "Автосалон", "Сотрудники, рейтинг, развитие", { openDealership() }), lpBottom())
        parent.addView(quick)

        section(parent, "Задания на сегодня", "Награды дают опыт салона и репутацию")
        missions.forEachIndexed { index, m ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = bg(panel, 13); setPadding(dp(12), dp(10), dp(12), dp(10)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label(m.title, 13f, Color.WHITE, true))
            info.addView(label("${m.progress}/${m.target} · награда € ${m.reward}", 11f, muted).apply { setPadding(0, dp(3), 0, 0) })
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            val b = if (m.claimed) label("✓", 20f, green, true) else button("Забрать", { claimMission(index) }, green)
            card.addView(b)
            parent.addView(card, lpBottom())
        }

        section(parent, "Популярные машины")
        listings.take(3).forEach { miniCarCard(parent, it) }
    }

    private fun marketPage(parent: LinearLayout) {
        section(parent, "Рынок автомобилей", "Все сделки виртуальные. У каждого города свой уровень цен.")
        val search = EditText(this).apply {
            hint = "Поиск: BMW, Golf, Audi..."
            setText(searchQuery)
            inputType = InputType.TYPE_CLASS_TEXT
            textSize = 14f
            setTextColor(Color.WHITE); setHintTextColor(muted)
            singleLine = true
            background = bg(panel, 14)
            setPadding(dp(13), dp(11), dp(13), dp(11))
        }
        val searchRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        searchRow.addView(search, LinearLayout.LayoutParams(0, dp(50), 1f).apply { rightMargin = dp(7) })
        searchRow.addView(button("Найти", { searchQuery = search.text.toString().trim(); render() }, accent), LinearLayout.LayoutParams(dp(90), dp(50)))
        parent.addView(searchRow)
        val chips = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(9), 0, dp(9)) }
        listOf("Все", "Седаны", "Хэтчбеки", "Спорт", "SUV").forEach { f ->
            chipRow.addView(pill(f, selectedFilter == f) { selectedFilter = f; render() }, LinearLayout.LayoutParams(-2, -2).apply { rightMargin = dp(7) })
        }
        chips.addView(chipRow); parent.addView(chips)

        val priceRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        priceRow.addView(label("До", 12f, muted))
        val seek = SeekBar(this).apply { max = 50; progress = maxPrice / 1000; setPadding(dp(5), 0, dp(5), 0) }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) maxPrice = max(5000, p * 1000) }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { render() }
        })
        priceRow.addView(seek, LinearLayout.LayoutParams(0, -2, 1f))
        priceRow.addView(label("€ $maxPrice", 12f, muted))
        parent.addView(priceRow)
        parent.addView(button("＋  Моё объявление", { createListing() }, accent2).apply { setPadding(dp(13), dp(12), dp(13), dp(12)) }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val q = searchQuery
        listings.filter {
            (it.city == currentCity || it.city == "Все") &&
            (selectedFilter == "Все" || it.category == selectedFilter) &&
            it.price <= maxPrice &&
            (q.isBlank() || it.name.contains(q, true) || it.details.contains(q, true))
        }.forEach { carCard(list, it) }
        if (list.childCount == 0) list.addView(label("Подходящих объявлений пока нет. Попробуй другой фильтр или город.", 13f, muted).apply { setPadding(0, dp(18), 0, dp(18)) })
        parent.addView(list)
    }

    private fun carCard(parent: LinearLayout, car: Car) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(panel, 16); setPadding(dp(9), dp(9), dp(9), dp(10)) }
        val image = ImageView(this).apply {
            setImageResource(car.image)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = bg(Color.rgb(15, 20, 28), 13)
        }
        card.addView(image, LinearLayout.LayoutParams(-1, dp(165)))
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(8), dp(4), 0) }
        val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        details.addView(label(car.name, 17f, Color.WHITE, true))
        details.addView(label("${car.details} · ${car.city}", 11f, muted).apply { setPadding(0, dp(3), 0, 0) })
        val condText = when {
            car.condition >= 90 -> "Отличное"
            car.condition >= 75 -> "Хорошее"
            car.condition >= 55 -> "Нормальное"
            else -> "Требует ремонта"
        }
        details.addView(label("${condText}${if (car.inspected) " · ✓ осмотр" else ""}", 11f, if (car.condition >= 75) green else yellow).apply { setPadding(0, dp(3), 0, 0) })
        line.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
        line.addView(label("€ ${car.price.formatMoney()}", 17f, green, true))
        card.addView(line)
        val actions = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), 0) }
        actions.addView(button("Подробнее", { carDetails(car) }), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(6) })
        actions.addView(button("Торг", { negotiate(car) }, accent2), LinearLayout.LayoutParams(0, -2, 1f))
        card.addView(actions)
        parent.addView(card, lpBottom(11))
    }

    private fun miniCarCard(parent: LinearLayout, car: Car) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; background = bg(panel, 13); setPadding(dp(8), dp(8), dp(8), dp(8)) }
        card.addView(ImageView(this).apply { setImageResource(car.image); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(dp(105), dp(72)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(9), 0, 0, 0) }
        info.addView(label(car.name, 14f, Color.WHITE, true))
        info.addView(label(car.details, 11f, muted).apply { setPadding(0, dp(3), 0, 0) })
        info.addView(label("€ ${car.price.formatMoney()}", 14f, green, true).apply { setPadding(0, dp(5), 0, 0) })
        card.addView(info)
        card.setOnClickListener { carDetails(car) }
        parent.addView(card, lpBottom())
    }

    private fun garagePage(parent: LinearLayout) {
        section(parent, "Мой гараж", "Состояние, обслуживание, тюнинг и будущая перепродажа.")
        val overview = LinearLayout(this).apply { background = bg(panel, 15); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        overview.addView(label("Мест: ${owned.size}/$garageCapacity", 15f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        overview.addView(label("Репутация $reputation", 13f, yellow, true))
        parent.addView(overview)
        if (owned.isEmpty()) {
            parent.addView(label("Гараж пуст. Купи первую машину на рынке.", 13f, muted).apply { setPadding(0, dp(16), 0, dp(16)) })
            return
        }
        owned.forEach { car ->
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(panel, 15); setPadding(dp(9), dp(9), dp(9), dp(10)) }
            card.addView(ImageView(this).apply { setImageResource(car.image); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(-1, dp(150)))
            card.addView(label(car.name, 17f, Color.WHITE, true).apply { setPadding(dp(4), dp(7), dp(4), 0) })
            card.addView(label("${car.details} · состояние ${car.condition}%", 11f, muted).apply { setPadding(dp(4), dp(3), dp(4), 0) })
            val acts = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), 0) }
            acts.addView(button("🔧 Сервис", { serviceCar(car) }), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(5) })
            acts.addView(button("✨ Тюнинг", { tuneCar(car) }, accent2), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(5) })
            acts.addView(button("Продать", { sellCar(car) }, green), LinearLayout.LayoutParams(0, -2, 1f))
            card.addView(acts)
            parent.addView(card, lpBottom(11))
        }
    }

    private fun bankPage(parent: LinearLayout) {
        section(parent, "Игровой банк", "Отдельное игровое финансовое приложение внутри CarMarket.")
        val account = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(Color.rgb(17, 65, 115), 18); setPadding(dp(16), dp(14), dp(16), dp(14)) }
        account.addView(label("CARBANK", 12f, Color.WHITE, true))
        account.addView(label("€ ${cash.formatMoney()}", 29f, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(4)) })
        account.addView(label("Накопления € ${savings.formatMoney()} · карта виртуальная", 11f, Color.rgb(215, 232, 255)))
        parent.addView(account)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(10), 0, 0) }
        row.addView(button("＋ 500", { deposit(500) }), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(5) })
        row.addView(button("Снять 500", { withdraw(500) }, panel2), LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(5) })
        parent.addView(row)
        section(parent, "Кредит")
        val loanCard = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(panel, 15); setPadding(dp(14), dp(12), dp(14), dp(12)) }
        loanCard.addView(label(if (loan == 0) "Доступен кредит € 5 000" else "Остаток кредита € ${loan.formatMoney()}", 15f, Color.WHITE, true))
        loanCard.addView(label(if (loan == 0) "Вернуть нужно € 5 500. Пока кредит не погашен, новый не выдаётся." else "Погаси долг и откроется новый лимит.", 11f, muted).apply { setPadding(0, dp(5), 0, dp(9)) })
        loanCard.addView(button(if (loan == 0) "Получить € 5 000" else "Погасить € ${loan.formatMoney()}", { if (loan == 0) takeLoan() else repayLoan() }, if (loan == 0) green else yellow))
        parent.addView(loanCard)
        section(parent, "История операций")
        if (history.isEmpty()) parent.addView(label("Операций пока нет.", 12f, muted))
        history.takeLast(8).asReversed().forEach { h -> parent.addView(label("• $h", 12f, Color.WHITE).apply { setPadding(0, dp(4), 0, 0) }) }
    }

    private fun profilePage(parent: LinearLayout) {
        section(parent, "Профиль игрока", "Развивай автосалон и открывай новые возможности.")
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = bg(panel, 16); setPadding(dp(15), dp(13), dp(15), dp(13)) }
        card.addView(label("Владелец CarMarket", 18f, Color.WHITE, true))
        card.addView(label("Уровень салона $dealershipLevel · XP $dealershipXp/100", 12f, muted).apply { setPadding(0, dp(5), 0, 0) })
        card.addView(label("Репутация $reputation · сделок $deals", 12f, yellow, true).apply { setPadding(0, dp(4), 0, dp(7)) })
        parent.addView(card)
        parent.addView(iconText("🏢", "Автосалон", "Улучшения, сотрудники, места", { openDealership() }), lpBottom())
        parent.addView(iconText("🗺️", "Карта Европы", "Амстердам, Берлин, Париж, Мюнхен, Роттердам", { openCities() }), lpBottom())
        parent.addView(iconText("🧾", "История сделок", "Покупки, продажи, торги", { openHistory() }), lpBottom())
        parent.addView(iconText("🏆", "Достижения", "Награды за стиль игры", { openAchievements() }), lpBottom())
        parent.addView(iconText("⚙️", "Настройки сохранения", "Сбросить локальный прогресс", { confirmReset() }), lpBottom())
    }

    private fun carDetails(car: Car) {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(4), 0, dp(4), 0) }
        box.addView(ImageView(this).apply { setImageResource(car.image); scaleType = ImageView.ScaleType.CENTER_CROP }, LinearLayout.LayoutParams(-1, dp(180)))
        box.addView(label("${car.details}\nСостояние: ${car.condition}%\nГород: ${car.city}\nПродавец: ${car.seller}", 13f, Color.DKGRAY).apply { setPadding(0, dp(8), 0, 0) })
        if (car.accident) box.addView(label("⚠ В истории есть отметка о ДТП", 12f, red, true).apply { setPadding(0, dp(7), 0, 0) })
        AlertDialog.Builder(this).setTitle(car.name).setView(box)
            .setNegativeButton("Закрыть", null)
            .setNeutralButton("Осмотр €150") { _, _ -> inspectCar(car) }
            .setPositiveButton("Купить") { _, _ -> buyCar(car) }.show()
    }

    private fun buyCar(car: Car) {
        if (car.seller == "Вы") { toast("Это твоё объявление."); return }
        if (owned.size >= garageCapacity) { toast("Гараж заполнен."); return }
        if (cash < car.price) { toast("Не хватает игровых денег."); return }
        cash -= car.price
        listings.remove(car)
        owned.add(car.copy())
        deals++
        reputation = min(100, reputation + 2)
        addHistory("Покупка ${car.name} за € ${car.price.formatMoney()}")
        advanceMission(0); advanceMission(1)
        saveGame(); render(); toast("Машина в гараже!")
    }

    private fun negotiate(car: Car) {
        if (car.seller == "Вы") { toast("Собственные объявления не торгуются с самим собой."); return }
        val start = max(500, (car.price * 0.86).toInt())
        val input = EditText(this).apply { hint = "Например: € ${start.formatMoney()}"; inputType = InputType.TYPE_CLASS_NUMBER; setSingleLine(true) }
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), dp(5), dp(18), 0) }
        layout.addView(label("Продавец: «Цена ${car.price.formatMoney()}»", 13f, Color.DKGRAY))
        layout.addView(label("Твоя задача — выбить скидку, но слишком низкая цена может сорвать сделку.", 11f, Color.GRAY).apply { setPadding(0, dp(5), 0, dp(7)) })
        layout.addView(input)
        AlertDialog.Builder(this).setTitle("Торг: ${car.name}").setView(layout)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Предложить") { _, _ -> processOffer(car, input.text.toString().toIntOrNull() ?: 0) }.show()
    }

    private fun processOffer(car: Car, offer: Int) {
        if (offer <= 0) { toast("Введи сумму."); return }
        val ratio = offer.toDouble() / car.price
        when {
            ratio >= 0.97 -> {
                AlertDialog.Builder(this).setTitle("Продавец согласен!").setMessage("Договорились за € ${offer.formatMoney()}.")
                    .setNegativeButton("Нет", null).setPositiveButton("Купить") { _, _ -> buyAtPrice(car, offer) }.show()
            }
            ratio >= 0.90 -> {
                val counter = ((offer + car.price) / 2 / 100) * 100
                AlertDialog.Builder(this).setTitle("Встречное предложение")
                    .setMessage("Продавец: «Могу отдать за € ${counter.formatMoney()}.»")
                    .setNegativeButton("Отказаться", null)
                    .setPositiveButton("Согласиться") { _, _ -> buyAtPrice(car, counter) }.show()
            }
            ratio >= 0.78 -> {
                reputation = max(0, reputation - 1)
                toast("Продавец недоволен и поднял цену.")
                AlertDialog.Builder(this).setTitle("Почти договорились")
                    .setMessage("Продавец предлагает € ${(car.price * 0.95).toInt().formatMoney()} и ждёт ответа.")
                    .setNegativeButton("Отмена", null)
                    .setPositiveButton("Принять") { _, _ -> buyAtPrice(car, (car.price * 0.95).toInt()) }.show()
                saveGame()
            }
            else -> toast("Продавец: «Слишком низко. Дальше торговаться не буду.»")
        }
    }

    private fun buyAtPrice(car: Car, price: Int) {
        if (cash < price) { toast("Не хватает игровых денег."); return }
        if (owned.size >= garageCapacity) { toast("Гараж заполнен."); return }
        cash -= price
        listings.remove(car)
        owned.add(car.copy(price = price))
        deals++
        reputation = min(100, reputation + 2)
        addHistory("Покупка после торга: ${car.name} · € ${price.formatMoney()}")
        advanceMission(0); advanceMission(1)
        saveGame(); render(); toast("Сделка закрыта!")
    }

    private fun createListing() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, dp(18), 0) }
        val name = EditText(this).apply { hint = "Марка и модель" }
        val price = EditText(this).apply { hint = "Цена (€)"; inputType = InputType.TYPE_CLASS_NUMBER }
        val km = EditText(this).apply { hint = "Пробег (км)"; inputType = InputType.TYPE_CLASS_NUMBER }
        form.addView(name); form.addView(price); form.addView(km)
        AlertDialog.Builder(this).setTitle("Новое объявление").setView(form)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Опубликовать") { _, _ ->
                val n = name.text.toString().trim(); val p = price.text.toString().toIntOrNull() ?: 0; val k = km.text.toString().toIntOrNull() ?: 0
                if (n.isBlank() || p < 500) toast("Укажи название и цену от €500.")
                else {
                    val img = car_bmw_m4
                    listings.add(0, Car(Random.nextInt(10000,99999), n, "Пробег ${k.formatMoney()} км · виртуальный владелец", p, 90, currentCity, "Вы", "Седаны", img))
                    addHistory("Создано объявление $n")
                    saveGame(); render(); toast("Объявление опубликовано!")
                }
            }.show()
    }

    private fun openCities() {
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(5), dp(16), 0) }
        cities.forEach { city ->
            val selected = city == currentCity
            val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; background = bg(panel, 13); setPadding(dp(12), dp(10), dp(12), dp(10)) }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(label("${if (selected) "📍" else "🏙️"} $city", 15f, Color.DKGRAY, true))
            info.addView(label("${listings.count { it.city == city }} объявлений · поездка €250", 11f, Color.GRAY).apply { setPadding(0, dp(3), 0, 0) })
            card.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            if (!selected) card.addView(button("Поехать", { travel(city) }), LinearLayout.LayoutParams(dp(105), -2))
            else card.addView(label("Здесь", 12f, green, true))
            list.addView(card, lpBottom())
        }
        AlertDialog.Builder(this).setTitle("Карта Европы").setView(list).setPositiveButton("Закрыть", null).show()
    }

    private fun travel(city: String) {
        if (cash < 250) { toast("Не хватает €250 на поездку."); return }
        cash -= 250
        currentCity = city
        addHistory("Поездка в $city · €250")
        advanceMission(2)
        saveGame(); render(); toast("Ты приехал в $city")
    }

    private fun openServiceHub() {
        val items = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(5), dp(16), 0) }
        items.addView(iconText("🔍", "Осмотр автомобиля", "Проверка перед покупкой · €150", { screen = Screen.MARKET; render() }), lpBottom())
        items.addView(iconText("🔧", "Ремонт", "Восстановить состояние автомобиля", { if (owned.isEmpty()) toast("Сначала купи машину.") else serviceCar(owned.first()) }), lpBottom())
        items.addView(iconText("✨", "Тюнинг", "Стиль и характеристики", { if (owned.isEmpty()) toast("Сначала купи машину.") else tuneCar(owned.first()) }), lpBottom())
        AlertDialog.Builder(this).setTitle("Сервис") .setView(items).setPositiveButton("Закрыть", null).show()
    }

    private fun inspectCar(car: Car) {
        if (car.inspected) { toast("Этот автомобиль уже осмотрен."); return }
        if (cash < 150) { toast("Не хватает €150."); return }
        cash -= 150
        car.inspected = true
        addHistory("Осмотр ${car.name} · €150")
        saveGame(); render()
        AlertDialog.Builder(this).setTitle("Отчёт осмотра").setMessage(
            "Кузов: ${if (car.accident) "есть следы ремонта" else "без серьёзных записей"}\n" +
            "Состояние: ${car.condition}%\n" +
            "Двигатель: ${if (car.condition > 70) "стабильный" else "требует внимания"}\n" +
            "Рекомендация: ${if (car.condition > 80) "можно рассматривать" else "заложи бюджет на сервис"}"
        ).setPositiveButton("Понятно", null).show()
    }

    private fun serviceCar(car: Car) {
        val cost = max(250, (100 - car.condition) * 30)
        AlertDialog.Builder(this).setTitle("Сервис: ${car.name}")
            .setMessage("Восстановить до 95% за €${cost.formatMoney()}?")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Ремонт") { _, _ ->
                if (cash < cost) toast("Не хватает денег.") else { cash -= cost; car.condition = 95; addHistory("Ремонт ${car.name} · €$cost"); saveGame(); render(); toast("Машина обслужена.") }
            }.show()
    }

    private fun tuneCar(car: Car) {
        val cost = 900 + car.tuned * 600
        AlertDialog.Builder(this).setTitle("Тюнинг: ${car.name}")
            .setMessage("Уровень тюнинга: ${car.tuned}/3\nСледующий апгрейд: €${cost.formatMoney()}\nБонус к цене продажи и репутации.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Установить") { _, _ ->
                if (car.tuned >= 3) toast("Максимальный уровень тюнинга.")
                else if (cash < cost) toast("Не хватает денег.")
                else { cash -= cost; car.tuned++; car.condition = min(100, car.condition + 2); addHistory("Тюнинг ${car.name} · €$cost"); saveGame(); render(); toast("Тюнинг установлен!") }
            }.show()
    }

    private fun sellCar(car: Car) {
        val sellPrice = (car.price * (0.82 + car.condition / 500.0) * (1 + car.tuned * 0.05)).toInt()
        AlertDialog.Builder(this).setTitle("Продать ${car.name}")
            .setMessage("Ориентир рынка: €${sellPrice.formatMoney()}\nСостояние: ${car.condition}% · тюнинг ${car.tuned}/3")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Выставить") { _, _ ->
                owned.remove(car)
                listings.add(0, car.copy(price = sellPrice, seller = "Вы", city = currentCity))
                deals++
                addHistory("Продажа ${car.name} · ожидаем €$sellPrice")
                advanceMission(1)
                saveGame(); render(); toast("Машина выставлена на рынок.")
            }.show()
    }

    private fun openDealership() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(5), dp(16), 0) }
        box.addView(label("Уровень салона: $dealershipLevel", 17f, Color.DKGRAY, true))
        box.addView(label("XP: $dealershipXp/100 · мест в гараже: ${8 + dealershipLevel - 1}", 12f, Color.GRAY).apply { setPadding(0, dp(4), 0, dp(9)) })
        val price = 4000 * dealershipLevel
        box.addView(label("Следующее улучшение: €${price.formatMoney()}", 13f, Color.DKGRAY))
        box.addView(button("Улучшить салон", { upgradeDealership(price) }, accent).apply { setPadding(dp(12), dp(12), dp(12), dp(12)) })
        box.addView(label("\nСотрудники", 16f, Color.DKGRAY, true))
        box.addView(label("• Переговорщик — повышает шанс на скидку\n• Механик — уменьшает стоимость ремонта\n• Менеджер — ускоряет получение XP", 12f, Color.GRAY).apply { setPadding(0, dp(5), 0, dp(7)) })
        box.addView(button("Нанять сотрудника €2500", { hireEmployee() }, green))
        AlertDialog.Builder(this).setTitle("Мой автосалон").setView(box).setPositiveButton("Закрыть", null).show()
    }

    private fun upgradeDealership(cost: Int) {
        if (cash < cost) { toast("Не хватает денег."); return }
        cash -= cost; reputation = min(100, reputation + 5); addXp(100)
        addHistory("Улучшен автосалон до уровня $dealershipLevel · €$cost")
        saveGame(); render(); toast("Новый уровень салона!")
    }

    private var employees = 0
    private fun hireEmployee() {
        if (cash < 2500) { toast("Не хватает €2500."); return }
        cash -= 2500; employees++; reputation = min(100, reputation + 3); addXp(30)
        addHistory("Нанят сотрудник · €2500"); saveGame(); render(); toast("Сотрудник нанят.")
    }

    private fun openHistory() {
        val text = if (history.isEmpty()) "История пуста." else history.takeLast(20).asReversed().joinToString("\n\n")
        AlertDialog.Builder(this).setTitle("История сделок").setMessage(text).setPositiveButton("Закрыть", null).show()
    }

    private fun openAchievements() {
        val achievements = listOf(
            "🚘 Первый автомобиль" to (owned.isNotEmpty()),
            "💬 Переговорщик" to (deals >= 2),
            "🌍 Путешественник" to (history.count { it.startsWith("Поездка") } >= 2),
            "🔧 Мастер сервиса" to owned.any { it.tuned > 0 || it.condition >= 95 },
            "🏢 Бизнесмен" to (dealershipLevel >= 2)
        )
        val msg = achievements.joinToString("\n") { (t, ok) -> "${if (ok) "✓" else "○"} $t" }
        AlertDialog.Builder(this).setTitle("Достижения").setMessage(msg).setPositiveButton("Понятно", null).show()
    }

    private fun claimMission(index: Int) {
        val m = missions[index]
        if (m.claimed || m.progress < m.target) { toast("Задание ещё не выполнено."); return }
        m.claimed = true; cash += m.reward; reputation = min(100, reputation + 1); addXp(20); addHistory("Награда за задание · €${m.reward}"); saveGame(); render()
    }

    private fun advanceMission(index: Int) { if (index in missions.indices) missions[index].progress = min(missions[index].target, missions[index].progress + 1) }

    private fun addXp(value: Int) { dealershipXp += value; while (dealershipXp >= 100) { dealershipXp -= 100; dealershipLevel++ } }

    private fun seedMissions() {
        missions.add(Mission("Купи автомобиль", 0, 1, 1000))
        missions.add(Mission("Проведи 2 сделки", 0, 2, 1500))
        missions.add(Mission("Посети новый город", 0, 1, 750))
    }

    private fun seedListings() {
        fun car(id:Int,name:String,details:String,price:Int,condition:Int,city:String,category:String,img:Int,acc:Boolean=false) = Car(id,name,details,price,condition,city,"Городской продавец",category,img,acc)
        listings.addAll(listOf(
            car(1,"BMW M4","2021 · 3.0 л · 45 000 км",45500,94,"Amsterdam","Спорт",car_bmw_m4),
            car(2,"Mercedes-Benz C-Class","2019 · 2.0 л · 72 000 км",28900,89,"Amsterdam","Седаны",car_mercedes_c),
            car(3,"Audi RS6 Avant","2020 · 4.0 л · 58 000 км",51200,91,"Amsterdam","Спорт",car_audi_rs6),
            car(4,"Volkswagen Golf","2018 · 1.4 л · 96 000 км",11900,86,"Berlin","Хэтчбеки",car_golf),
            car(5,"Toyota Corolla","2017 · 1.6 л · 112 000 км",10500,83,"Paris","Седаны",car_corolla),
            car(6,"Volvo V40","2016 · 2.0 л · 121 000 км",9800,80,"Munich","Хэтчбеки",car_volvo_v40),
            car(7,"Ford Focus","2017 · 1.0 л · 103 000 км",8900,72,"Rotterdam","Хэтчбеки",car_focus),
            car(8,"Toyota Land Cruiser","2016 · 4.5 л · 120 000 км",33400,78,"Rotterdam","SUV",car_land_cruiser,true),
            car(9,"Tesla Model 3","2022 · EV · 64 000 км",31500,93,"Berlin","Седаны",car_tesla_3),
            car(10,"Peugeot 308","2020 · 1.2 л · 61 000 км",14200,88,"Paris","Хэтчбеки",car_peugeot_308)
        ))
    }

    private fun deposit(amount: Int) { if (cash < amount) toast("Не хватает денег.") else { cash -= amount; savings += amount; addHistory("Вклад €$amount"); saveGame(); render() } }
    private fun withdraw(amount: Int) { if (savings < amount) toast("Недостаточно накоплений.") else { savings -= amount; cash += amount; addHistory("Снятие €$amount"); saveGame(); render() } }
    private fun takeLoan() { cash += 5000; loan = 5500; addHistory("Получен игровой кредит €5000"); saveGame(); render(); toast("Кредит зачислен.") }
    private fun repayLoan() { if (cash < loan) toast("Недостаточно денег для погашения.") else { cash -= loan; loan = 0; addHistory("Кредит погашен"); saveGame(); render(); toast("Кредит погашен.") } }

    private fun addHistory(s: String) { history.add(s); if (history.size > 60) history.removeAt(0) }

    private fun saveGame() {
        val p = getSharedPreferences("carmarket_save_v2", MODE_PRIVATE)
        fun carObj(c: Car) = JSONObject().put("id", c.id).put("name", c.name).put("details", c.details).put("price", c.price)
            .put("condition", c.condition).put("city", c.city).put("seller", c.seller).put("category", c.category).put("image", c.image).put("accident", c.accident).put("tuned", c.tuned).put("inspected", c.inspected)
        val own = JSONArray(); owned.forEach { own.put(carObj(it)) }
        val market = JSONArray(); listings.forEach { market.put(carObj(it)) }
        val hist = JSONArray(); history.forEach { hist.put(it) }
        val ms = JSONArray(); missions.forEach { m -> ms.put(JSONObject().put("title",m.title).put("progress",m.progress).put("target",m.target).put("reward",m.reward).put("claimed",m.claimed)) }
        p.edit().putInt("cash", cash).putInt("savings", savings).putInt("loan", loan).putString("city", currentCity).putInt("level",dealershipLevel)
            .putInt("xp",dealershipXp).putInt("rep",reputation).putInt("deals",deals).putInt("employees",employees)
            .putString("owned", own.toString()).putString("listings", market.toString())
            .putString("history",hist.toString()).putString("missions",ms.toString()).apply()
    }

    private fun loadGame() {
        val p = getSharedPreferences("carmarket_save_v2", MODE_PRIVATE)
        cash = p.getInt("cash",25000); savings=p.getInt("savings",0); loan=p.getInt("loan",0); currentCity=p.getString("city","Amsterdam") ?: "Amsterdam"
        dealershipLevel=p.getInt("level",1); dealershipXp=p.getInt("xp",0); reputation=p.getInt("rep",15); deals=p.getInt("deals",0); employees=p.getInt("employees",0)
        fun readCars(key:String): List<Car> {
            val a=JSONArray(p.getString(key,"[]")); val r=mutableListOf<Car>()
            for(i in 0 until a.length()) { val o=a.getJSONObject(i); r.add(Car(o.optInt("id"),o.optString("name"),o.optString("details"),o.optInt("price"),o.optInt("condition",85),o.optString("city","Amsterdam"),o.optString("seller","Вы"),o.optString("category","Седаны"),o.optInt("image",car_bmw_m4),o.optBoolean("accident",false),o.optInt("tuned",0),o.optBoolean("inspected",false))) }
            return r
        }
        owned.addAll(readCars("owned"))
        if (p.contains("listings")) {
            listings.addAll(readCars("listings"))
            hasSavedMarket = true
        } else {
            // Migrate older saves, which stored only player-created advertisements.
            listings.addAll(readCars("ads"))
            hasSavedMarket = false
        }
        if (currentCity !in cities) currentCity = "Amsterdam"
        val h=JSONArray(p.getString("history","[]")); for(i in 0 until h.length()) history.add(h.getString(i))
        val ms=JSONArray(p.getString("missions","[]")); for(i in 0 until ms.length()){val o=ms.getJSONObject(i); missions.add(Mission(o.optString("title"),o.optInt("progress"),o.optInt("target"),o.optInt("reward"),o.optBoolean("claimed")))}
    }

    private fun confirmReset() {
        AlertDialog.Builder(this).setTitle("Сбросить игру?").setMessage("Удалятся машины, деньги, история и прогресс этого телефона.")
            .setNegativeButton("Отмена", null).setPositiveButton("Сбросить") { _, _ -> getSharedPreferences("carmarket_save_v2", MODE_PRIVATE).edit().clear().apply(); owned.clear(); listings.clear(); history.clear(); missions.clear(); cash=25000; savings=0; loan=0; currentCity="Amsterdam"; dealershipLevel=1; dealershipXp=0; reputation=15; deals=0; employees=0; seedListings(); seedMissions(); render() }.show()
    }

    private fun lpBottom(bottom: Int = 7) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun Int.formatMoney(): String = String.format("%,d", this).replace(',', ' ')

    companion object {
        private val car_bmw_m4 = com.carmarket.app.R.drawable.car_bmw_m4
        private val car_mercedes_c = com.carmarket.app.R.drawable.car_mercedes_c
        private val car_audi_rs6 = com.carmarket.app.R.drawable.car_audi_rs6
        private val car_golf = com.carmarket.app.R.drawable.car_golf
        private val car_corolla = com.carmarket.app.R.drawable.car_corolla
        private val car_volvo_v40 = com.carmarket.app.R.drawable.car_volvo_v40
        private val car_focus = com.carmarket.app.R.drawable.car_focus
        private val car_land_cruiser = com.carmarket.app.R.drawable.car_land_cruiser
        private val car_tesla_3 = com.carmarket.app.R.drawable.car_tesla_3
        private val car_peugeot_308 = com.carmarket.app.R.drawable.car_peugeot_308
    }
}
