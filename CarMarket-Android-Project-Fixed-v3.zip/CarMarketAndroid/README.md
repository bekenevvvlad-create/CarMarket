# CarMarket 2.0

CarMarket is a virtual Android car-market simulator. All money, banking and deals are fictional and stored locally on the device.

## Included
- Dark Android interface with Home, Market, Garage, Bank and Profile tabs
- Ten bundled car images and fictional listings across Amsterdam, Berlin, Paris, Munich and Rotterdam
- Search, vehicle-category filters and maximum-price filter
- Car details, inspection report and fictional negotiation
- Buy, own, service, tune and list cars for sale
- Virtual savings and a fictional loan
- City travel, dealership upgrades, employees, missions, achievements and local history
- Local save data using SharedPreferences

## Build
The project folder is `CarMarketAndroid`. Use Java 17 and Gradle 8.11.1 or a compatible newer Gradle version with Android Gradle Plugin 8.9.2. The GitHub Actions workflow should extract the project archive and run `gradle --no-daemon assembleDebug` from this folder.
