package com.carmarket.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val cities = listOf("Amsterdam", "Berlin", "Paris", "Munich", "Rotterdam")
    private val dark = Color.rgb(18, 22, 30)
    private val panel = Color.rgb(29, 35, 46)
    private val accent = Color.rgb(64, 132, 245)
    private val green = Color.rgb(125, 220, 160)
    private lateinit var root: LinearLayout
    private var tab = "market"
    private var city = "Amsterdam"
    private var cash = 25000
    private var savings = 0
    private var loan = 0
    private val owned = mutableListOf<Car>()
    private val listings = mutableListOf<Car>()

    data class Car(
        val name: String, val details: String, val price: Int,
        val condition: String, val city: String, val seller: String = "Городской продавец",
        val ownedByPlayer: Boolean = false
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadGame()
        if (listings.isEmpty()) seedListings()
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 16) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun label(value: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun actionButton(value: String, action: () -> Unit) =
        TextView(this).apply {
            text = value
            textSize = 14f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = rounded(accent, 12)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setOnClickListener { action() }
        }

    private fun seedListings() {
        val samples = listOf(
            Car("BMW 3 Series", "2016 · 2.0 л · 148 000 км", 12900, "Хорошее состояние", "Amsterdam"),
            Car("Volkswagen Golf", "2018 · 1.4 л · 96 000 км", 10500, "Без замечаний", "Berlin"),
            Car("Toyota Corolla", "2017 · 1.6 л · 112 000 км", 11200, "Один владелец", "Paris"),
            Car("Mercedes-Benz C-Class", "2015 · 2.1 л · 161 000 км", 13700, "Сервисная история", "Munich"),
            Car("Audi A3", "2019 · 1.5 л · 82 000 км", 14900, "Хорошее состояние", "Rotterdam"),
            Car("Ford Focus", "2017 · 1.0 л · 103 000 км", 8900, "Есть следы эксплуатации", "Amsterdam"),
            Car("Volvo V40", "2016 · 2.0 л · 121 000 км", 9900, "Ухоженный автомобиль", "Berlin")
        )
        listings.addAll(samples)
    }

    private fun saveGame() {
        val prefs = getSharedPreferences("carmarket_save", MODE_PRIVATE)
        val cars = JSONArray()
        owned.forEach { c ->
            cars.put(JSONObject().put("name", c.name).put("details", c.details)
                .put("price", c.price).put("condition", c.condition).put("city", c.city))
        }
        val ads = JSONArray()
        listings.filter { it.seller == "Вы" }.forEach { c ->
            ads.put(JSONObject().put("name", c.name).put("details", c.details)
                .put("price", c.price).put("condition", c.condition).put("city", c.city))
        }
        prefs.edit().putInt("cash", cash).putInt("savings", savings).putInt("loan", loan)
            .putString("city", city).putString("owned", cars.toString()).putString("ads", ads.toString()).apply()
    }

    private fun loadGame() {
        val p = getSharedPreferences("carmarket_save", MODE_PRIVATE)
        cash = p.getInt("cash", 25000)
        savings = p.getInt("savings", 0)
        loan = p.getInt("loan", 0)
        city = p.getString("city", "Amsterdam") ?: "Amsterdam"
        fun readCars(key: String, seller: String, ownedByPlayer: Boolean): List<Car> {
            val result = mutableListOf<Car>()
            val arr = JSONArray(p.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(Car(o.optString("name"), o.optString("details"), o.optInt("price"),
                    o.optString("condition"), o.optString("city"), seller, ownedByPlayer))
            }
            return result
        }
        owned.addAll(readCars("owned", "Вы", true))
        listings.addAll(readCars("ads", "Вы", false))
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(dp(16), dp(12), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("🚗 CarMarket", 24f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("€ $cash", 16f, green, true))
        root.addView(header)
        root.addView(label("$city · Автомобильный рынок", 13f, Color.LTGRAY).apply {
            setPadding(0, dp(5), 0, dp(12))
        })
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        when (tab) {
            "market" -> marketPage(content)
            "cities" -> citiesPage(content)
            "bank" -> bankPage(content)
            "garage" -> garagePage(content)
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(2))
        }
        listOf("market" to "Рынок", "cities" to "Города", "bank" to "Банк", "garage" to "Гараж").forEach { (key, title) ->
            val selected = tab == key
            val item = label((if (selected) "● " else "") + title, 12f,
                if (selected) Color.WHITE else Color.LTGRAY, selected).apply {
                gravity = Gravity.CENTER
                background = if (selected) rounded(accent, 10) else rounded(dark, 10)
                setPadding(dp(8), dp(11), dp(8), dp(11))
                setOnClickListener { tab = key; render() }
            }
            nav.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun section(parent: LinearLayout, title: String, subtitle: String? = null) {
        parent.addView(label(title, 20f, Color.WHITE, true).apply { setPadding(0, dp(12), 0, dp(6)) })
        if (subtitle != null) parent.addView(label(subtitle, 13f, Color.LTGRAY).apply { setPadding(0, 0, 0, dp(8)) })
    }

    private fun marketPage(parent: LinearLayout) {
        section(parent, "Объявления", "Ищи автомобиль в текущем городе или смотри все предложения.")
        val search = EditText(this).apply {
            hint = "Марка или модель"
            textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setSingleLine(true); setPadding(dp(13), dp(10), dp(13), dp(10)); background = rounded(panel, 12)
        }
        parent.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        val all = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        parent.addView(all)
        fun show(query: String) {
            all.removeAllViews()
            listings.filter { (it.city == city) && (it.name.contains(query, true) || it.details.contains(query, true)) }
                .forEach { carCard(all, it, false) }
            if (all.childCount == 0) all.addView(label("В этом городе пока нет подходящих объявлений.", 14f, Color.LTGRAY).apply {
                setPadding(0, dp(14), 0, dp(14))
            })
        }
        show("")
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { show(s?.toString() ?: "") }
            override fun afterTextChanged(s: Editable?) {}
        })
        parent.addView(actionButton("＋ Разместить объявление") { createListing() }.apply {
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12); bottomMargin = dp(12) })
    }

    private fun carCard(parent: LinearLayout, car: Car, isOwned: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(panel, 15)
            setPadding(dp(13), dp(12), dp(13), dp(12))
        }
        val image = label("🚘", 38f, Color.WHITE).apply {
            gravity = Gravity.CENTER; background = rounded(Color.rgb(43, 51, 65), 12)
        }
        card.addView(image, LinearLayout.LayoutParams(-1, dp(94)))
        card.addView(label(car.name, 17f, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(2)) })
        card.addView(label(car.details, 12f, Color.LTGRAY))
        card.addView(label("${car.condition} · ${car.city}", 12f, Color.LTGRAY).apply { setPadding(0, dp(4), 0, dp(6)) })
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        row.addView(label("€ ${car.price}", 18f, green, true), LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(actionButton(if (isOwned) "Продать" else "Подробнее") {
            if (isOwned) sellCar(car) else carDetails(car)
        })
        card.addView(row)
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(11) })
    }

    private fun carDetails(car: Car) {
        val msg = "${car.details}\n${car.condition}\nГород: ${car.city}\nПродавец: ${car.seller}\nЦена: € ${car.price}\n\nПокупка использует только игровые деньги."
        AlertDialog.Builder(this).setTitle(car.name).setMessage(msg)
            .setNegativeButton("Закрыть", null)
            .setPositiveButton("Купить") { _, _ ->
                if (car.seller == "Вы") toast("Это твоё объявление.")
                else if (cash < car.price) toast("Недостаточно игровых денег.")
                else {
                    cash -= car.price
                    listings.remove(car)
                    owned.add(car.copy(ownedByPlayer = true, seller = "Вы"))
                    saveGame(); render(); toast("Автомобиль добавлен в гараж!")
                }
            }.show()
    }

    private fun createListing() {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0)
        }
        val name = EditText(this).apply { hint = "Марка и модель" }
        val price = EditText(this).apply { hint = "Цена (€)"; inputType = 2 }
        form.addView(name); form.addView(price)
        AlertDialog.Builder(this).setTitle("Новое объявление").setView(form)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Опубликовать") { _, _ ->
                val n = name.text.toString().trim()
                val p = price.text.toString().toIntOrNull()
                if (n.isBlank() || p == null || p < 1) toast("Введи название и корректную цену.")
                else {
                    listings.add(0, Car(n, "Игровое объявление · состояние не указано", p,
                        "Продавец: вы", city, "Вы"))
                    saveGame(); render(); toast("Объявление опубликовано.")
                }
            }.show()
    }

    private fun citiesPage(parent: LinearLayout) {
        section(parent, "Города", "Путешествуй по игровому миру и ищи предложения в других местах.")
        cities.forEach { destination ->
            val selected = destination == city
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(panel, 14)
                setPadding(dp(14), dp(12), dp(14), dp(12))
            }
            card.addView(label((if (selected) "📍 " else "🏙️ ") + destination, 17f, Color.WHITE, true))
            card.addView(label("${listings.count { it.city == destination }} объявлений · Поездка: € 250", 13f, Color.LTGRAY)
                .apply { setPadding(0, dp(4), 0, dp(8)) })
            if (!selected) card.addView(actionButton("Поехать") {
                if (cash < 250) toast("Недостаточно игровых денег на поездку.")
                else {
                    cash -= 250; city = destination; saveGame(); render()
                    toast("Ты приехал(а) в $destination!")
                }
            })
            else card.addView(label("Текущий город", 13f, green, true))
            parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        }
    }

    private fun bankPage(parent: LinearLayout) {
        section(parent, "Игровой банк", "Все средства здесь виртуальные и существуют только в игре.")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(panel, 16)
            setPadding(dp(16), dp(15), dp(16), dp(15))
        }
        box.addView(label("Наличные: € $cash", 17f, green, true))
        box.addView(label("Накопления: € $savings", 16f, Color.WHITE, true).apply { setPadding(0, dp(6), 0, dp(6)) })
        box.addView(label("Остаток игрового кредита: € $loan", 14f, Color.LTGRAY))
        parent.addView(box)
        parent.addView(actionButton("Положить € 500 в накопления") {
            if (cash < 500) toast("Недостаточно игровых денег.")
            else { cash -= 500; savings += 500; saveGame(); render() }
        }.apply { setPadding(dp(10), dp(14), dp(10), dp(14)) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        parent.addView(actionButton("Снять € 500") {
            if (savings < 500) toast("В накоплениях недостаточно средств.")
            else { savings -= 500; cash += 500; saveGame(); render() }
        }.apply { setPadding(dp(10), dp(14), dp(10), dp(14)) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        section(parent, "Предложение банка")
        val offer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(panel, 16)
            setPadding(dp(15), dp(13), dp(15), dp(13))
        }
        offer.addView(label("Игровой кредит: € 2 000", 17f, Color.WHITE, true))
        offer.addView(label("Вернуть нужно € 2 200. Кредит можно взять один раз, пока предыдущий не погашен.", 13f, Color.LTGRAY)
            .apply { setPadding(0, dp(5), 0, dp(10)) })
        offer.addView(actionButton(if (loan == 0) "Принять предложение" else "Погасить кредит (€ $loan") {
            if (loan == 0) { loan = 2200; cash += 2000; saveGame(); render() }
            else if (cash >= loan) { cash -= loan; loan = 0; saveGame(); render(); toast("Игровой кредит погашен.") }
            else toast("Недостаточно игровых денег для погашения.")
        })
        parent.addView(offer, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
    }

    private fun garagePage(parent: LinearLayout) {
        section(parent, "Мой гараж", "Здесь находятся купленные автомобили.")
        parent.addView(label("Автомобилей: ${owned.size}", 14f, Color.LTGRAY).apply {
            setPadding(0, 0, 0, dp(10))
        })
        if (owned.isEmpty()) parent.addView(label("Гараж пока пуст. Найди машину на рынке!", 14f, Color.LTGRAY)
            .apply { setPadding(0, dp(12), 0, dp(12)) })
        owned.toList().forEach { carCard(parent, it, true) }
    }

    private fun sellCar(car: Car) {
        AlertDialog.Builder(this).setTitle("Продать ${car.name}")
            .setMessage("Выставить автомобиль на рынок за € ${car.price}? Это игровая сделка.")
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Продать") { _, _ ->
                owned.remove(car)
                cash += car.price
                saveGame(); render(); toast("Автомобиль продан.")
            }.show()
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
