# CarMarket

A native Android starter app for a fictional car classifieds/trading game.

## Build
Open this project in Android Studio, or use Gradle 8.11.1 with JDK 17:
`gradle assembleDebug`

The first prototype shows fictional listings and a search field. Transactions and listing creation are planned for later versions.
