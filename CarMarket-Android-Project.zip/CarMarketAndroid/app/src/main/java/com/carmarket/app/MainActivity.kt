package com.carmarket.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val listings = listOf(
        Car("BMW 3 Series", "2016 · 2.0 л · 148 000 км", "€ 12 900", "Хорошее состояние"),
        Car("Volkswagen Golf", "2018 · 1.4 л · 96 000 км", "€ 10 500", "Без замечаний"),
        Car("Toyota Corolla", "2017 · 1.6 л · 112 000 км", "€ 11 200", "Один владелец"),
        Car("Mercedes-Benz C-Class", "2015 · 2.1 л · 161 000 км", "€ 13 700", "Есть сервисная история")
    )
    private var balance = 25000
    private val dark = Color.rgb(18, 22, 30)
    private val panel = Color.rgb(29, 35, 46)
    private val accent = Color.rgb(64, 132, 245)
    private lateinit var root: LinearLayout
    private lateinit var balanceLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 16): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(value: String, action: () -> Unit): TextView =
        text(value, 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            background = rounded(accent, 12)
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setOnClickListener { action() }
        }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(dark)
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(text("🚗  CarMarket", 25f, Color.WHITE, true), LinearLayout.LayoutParams(0, -2, 1f))
        balanceLabel = text("€ $balance", 16f, Color.rgb(125, 220, 160), true)
        top.addView(balanceLabel)
        content.addView(top)
        content.addView(text("Автомобильный рынок", 14f, Color.LTGRAY).apply {
            setPadding(0, dp(6), 0, dp(18))
        })
        val search = EditText(this).apply {
            hint = "Марка, модель или объявление"
            textSize = 14f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(panel, 12)
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(50)))
        content.addView(text("Свежие объявления", 20f, Color.WHITE, true).apply {
            setPadding(0, dp(20), 0, dp(10))
        })
        val cards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun showCards(query: String = "") {
            cards.removeAllViews()
            listings.filter { it.name.contains(query, true) || it.details.contains(query, true) }
                .forEach { car ->
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        background = rounded(panel, 16)
                        setPadding(dp(15), dp(13), dp(15), dp(13))
                    }
                    val visual = TextView(this).apply {
                        text = "🚘"
                        textSize = 42f
                        gravity = Gravity.CENTER
                        background = rounded(Color.rgb(43, 51, 65), 12)
                    }
                    card.addView(visual, LinearLayout.LayoutParams(-1, dp(112)))
                    card.addView(text(car.name, 18f, Color.WHITE, true).apply {
                        setPadding(0, dp(10), 0, dp(3))
                    })
                    card.addView(text(car.details, 13f, Color.LTGRAY))
                    card.addView(text(car.condition, 13f, Color.rgb(180, 190, 205)).apply {
                        setPadding(0, dp(5), 0, dp(8))
                    })
                    val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
                    row.addView(text(car.price, 19f, Color.rgb(125, 220, 160), true), LinearLayout.LayoutParams(0, -2, 1f))
                    row.addView(button("Подробнее") { showDetails(car) })
                    card.addView(row)
                    cards.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(12) })
                }
        }
        showCards()
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { showCards(s?.toString() ?: "") }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        content.addView(cards)
        content.addView(button("＋  Разместить объявление") {
            Toast.makeText(this, "Создание объявления добавим следующим этапом", Toast.LENGTH_SHORT).show()
        }.apply { setPadding(dp(12), dp(15), dp(12), dp(15)) },
            LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(16) })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(text("Главная       Избранное       Мой гараж", 13f, Color.LTGRAY).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(8))
        })
        setContentView(root)
    }

    private fun showDetails(car: Car) {
        android.app.AlertDialog.Builder(this)
            .setTitle(car.name)
            .setMessage("${car.details}\n${car.condition}\nЦена: ${car.price}\n\nЭто тестовое объявление. Покупки пока отключены.")
            .setPositiveButton("Понятно", null)
            .show()
    }

    data class Car(val name: String, val details: String, val price: String, val condition: String)
}
